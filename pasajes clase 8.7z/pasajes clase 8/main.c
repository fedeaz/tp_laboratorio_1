#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void miFuncion (char [] [20], int);

int main()
{

    char nombres [5] [20]= {"juan carlos", "luis", "aNa", "albErto"}; //como tienen mayusculas por el medio tengo que planchar los nombres

    miFuncion(nombres,5);

    return 0;
}

void miFuncion (char vec[] [20], int filas)
{
    for(int i=0; i<filas; i++)
    {
        strlwr(vec[i]); //planchar la el nombre

        for(int k=0;k<20;k++)
        {
            if(vec[i][k] == ' ')//recorre las columnas hasta que este en un espacio
            {
                vec[i][k+1] = toupper(vec[i][k+1]); //cuando esta en un espacio al siguiente lo pone en mayusculas
            }
        }
        vec[i][0] = toupper(vec[i][0]);
        printf("%s \n", vec[i]);
    }
}
