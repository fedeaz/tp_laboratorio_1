#include <stdio.h>
#include <stdlib.h>
typedef struct
  {
        char nombre[20];
        int legajo;
        float sueldo;

        char sexo ;
    }eEmpleado;

void mostrarEmpleado(eEmpleado);



int main()
{

    eEmpleado unEmpleado ={"Juan", 1111, 1000.75, 'm'};
    eEmpleado otroEmpleado;
    otroEmpleado = unEmpleado;
/*
    printf("Ingrese nombre: ");
    gets(unEmpleado.nombre);

    printf("Ingrese legajo: ");

    scanf("%d", &unEmpleado.legajo);

    printf("ingrese sueldo: ");
    scanf("%f", &unEmpleado.sueldo);
    printf("ingrese sexo");
    fflush(stdin);
    scanf("%c", &unEmpleado.sexo);
*/

   /*
    unEmpleado.legajo = 1234; //hard code
    strcpy(unEmpleado.nombre, "Juan"); // hard code
    unEmpleado.sueldo = 50000,50;// hard code
    unEmpleado.sexo = 'm';//hard code
   */

     mostrarEmpleado(otroEmpleado);

    return 0;
}

void mostrarEmpleado(eEmpleado emp)
{
    printf("nombre : %s \n",emp.nombre );

    printf("legajo : %d \n",emp.legajo);

    printf("Sueldo : %.2f \n",emp.sueldo );

    printf("Sexo : %c \n",emp.sexo );

}

