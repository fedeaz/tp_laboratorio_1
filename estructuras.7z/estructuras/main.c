#include <stdio.h>
#include <stdlib.h>
typedef struct
  {
        char nombre[20];
        int legajo;
        float sueldo;
        char sexo ;
    }eEmpleado;

void mostrarEmpleado(eEmpleado);
void mostrarEmpleados(eEmpleado vec[], int tam);
void ordenarEmpleados(eEmpleado[], int);



int main()
{



    eEmpleado platel[3] ={{"Juan", 1111, 1000.75, 'm'},{"ana", 2222, 20000,'f'},{"cacho", 3333, 30000, 'm'}};

   // mostrarEmpleados(platel, 3);

    ordenarEmpleados(platel, 3);

    mostrarEmpleados(platel,3);

    /*eEmpleado otroEmpleado;
    otroEmpleado = unEmpleado;*/
/*
    printf("Ingrese nombre: ");
    gets(unEmpleado.nombre);

    printf("Ingrese legajo: ");

    scanf("%d", &unEmpleado.legajo);

    printf("ingrese sueldo: ");
    scanf("%f", &unEmpleado.sueldo);
    printf("ingrese sexo");
    fflush(stdin);
    scanf("%c", &unEmpleado.sexo);
*/

   /*
    unEmpleado.legajo = 1234; //hard code
    strcpy(unEmpleado.nombre, "Juan"); // hard code
    unEmpleado.sueldo = 50000,50;// hard code
    unEmpleado.sexo = 'm';//hard code
   */

    /* mostrarEmpleado(otroEmpleado);*/

    return 0;
}


void mostrarEmpleado(eEmpleado emp)
{
    printf("nombre : %s \n",emp.nombre );

    printf("legajo : %d \n",emp.legajo);

    printf("Sueldo : %.2f \n",emp.sueldo );

    printf("Sexo : %c \n",emp.sexo );

}

void mostrarEmpleados(eEmpleado vec[], int tam)
{
    for(int i =0; i<tam;i++)
    {
        mostrarEmpleado(vec[i]);
    }
}

void ordenarEmpleados(eEmpleado vec[], int tam)
{
    eEmpleado aux;

    for(int i =0; i<tam-1; i++)
    {
        for(int j =0; j<tam; j++)
        {
            if(strcmp(vec[i].nombre, vec[j].nombre) > 0)
            {
                aux = vec[i];
                vec[i] = vec[j];
                vec[j] = aux;
            }
        }
    }
}



